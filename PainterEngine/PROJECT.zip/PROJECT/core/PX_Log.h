#ifndef __PX_LOG_H
#define __PX_LOG_H
void PX_LOG(char fmt[]);
void PX_ERROR(char fmt[]);
char *PX_GETLOG(void);
void PX_ASSERT(void);
#endif
