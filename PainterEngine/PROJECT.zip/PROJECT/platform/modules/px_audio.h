
#ifndef PX_AUDIO_H
#define PX_AUDIO_H

#include "../../core/PX_Sound.h"

int  PX_AudioInitialize(PX_SoundPlay *soundPlay);
void PX_AudioSetVolume(unsigned int volume);


#endif
