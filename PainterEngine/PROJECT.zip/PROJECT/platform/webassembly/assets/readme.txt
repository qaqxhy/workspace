Put your resource files in this folder
use "assets/filename" to access your resource files.

